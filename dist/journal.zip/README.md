# AcademiesJournal

This is a fork of the ghost theme [Journal](https://github.com/TryGhost/Journal).

# Instructions

1. Download this theme
2. Log into Ghost, and go to the `Design` settings area to upload the zip file

# Setup

The process for using this theme on windows and running it can be found in [this](https://www.youtube.com/watch?v=nWpti1YQ2Tw) video.

# Copyright & License

[MIT license](LICENSE).